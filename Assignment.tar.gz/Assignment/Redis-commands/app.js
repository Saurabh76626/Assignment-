const express= require('express');
const redis = require("redis");

const Ioredis = require("ioredis");
const ioredis = new Ioredis(); 


// Creating Redis Client
let client = redis.createClient();
client.on('connect', function(){
  console.log('Connected to Redis Server');
});

const app= express();
const port= 8000;


// set key-value pair {key= name}
client.set('name', 'Human',(err, response)=> {
  if(response){  
      console.log(response);
      return; 
  }
  console.log(err);
});


// set key-value pair {key= profession}
client.set('profession', 'Software Engineer',(err, response)=> {
  if(response){  
      console.log(response);
      return; 
  }
  console.log(err);
});


// get value from key {key= name}
client.get('name', (err, response)=> {
  if(response){  
      console.log("name- " + response);
      return; 
  }
  console.log(err);
});


// get value from key {key= profession}
client.get('profession', (err, response)=> {
  if(response){  
      console.log("profession- " + response);
      return; 
  }
  console.log(err);
});



// value associated with key="name" expires in 3 seconds
client.expire('name', 3);


// this function runs every second until the timeout (3 seconds)
const timer = setInterval(()=>{
    client.get('name',(err, response)=> {
        if(response){
            console.log("my name is: " + response);
            return;
        }
        console.log("My name is expired.");  
        clearTimeout(timer);
    });
    
    client.get('profession',(err, response)=> {
        if(response){
            console.log("my profession is: " + response);
            return;
        }
    });
}, 1000);


// adding all the members with their corrosponding scores to the sorted set (SortedSet)
client.zadd("SortedSet", 5, "five");
client.zadd("SortedSet", 3, "three");
client.zadd("SortedSet", 4, "four");
client.zadd("SortedSet", 1, "one");
client.zadd("SortedSet", 2, "two");


// returns the elements (member-score pairs) of specified range in the sorted set
ioredis.zrange("SortedSet", 0, 4, "WITHSCORES").then((res) => console.log(res)); 


// returns the rank of member("three") in the sorted set
ioredis.zrank("SortedSet", "three").then((rank)=> console.log(rank));


app.listen(port,()=> console.log(`Started on port ${port}`));

