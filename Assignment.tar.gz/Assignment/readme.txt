How to use the files -

- Run 'npm install' in the extracted code folder to install the modules in application.

- Run 'redis-server' to start redis server.

- Run 'nodemon app' (or 'node app') to start node server and run the application.

- Run 'redis-cli' to create a client, here we can run commands to check values of keys, 
  elements in sorted set etc.